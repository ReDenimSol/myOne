import java.io.*;
import java.net.*;
import org.apache.http.*;

public class InternetWork
{
	public void goWget(String url, File to)
	{
		URL urlToWget = null;
		
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(urlToWget.openStream()));
			BufferedWriter bw = new BufferedWriter(new FileWriter(to));
			
			String htmlStr = "";
			StringBuffer sb = new StringBuffer();
			
			while ((htmlStr = br.readLine()) != null)
			{
				sb.append(htmlStr);
				bw.append(sb.toString());
			}
			bw.append("By Sabur Akhmedov");
			
			bw.close();
			br.close();
			
		} catch (IOException ioe)
		{
			System.out.println("Error.");
		} finally {
			
			System.out.println("Ыы");
			
		}
	}
	protected boolean TCP(String server, int port)
	{
		return true;
	}
	public void HTTP(String url) throws IOException {
		URL ur = null;
		
		try
		{
			ur = new URL(url);
			
			org.apache2.io.HTTPRequest.sendOpenGetRequest(url, "Mozila");
			
			// Дописать....
			
		} catch (MalformedURLException mu) {
			System.out.println("Error.");
		}

	}
}