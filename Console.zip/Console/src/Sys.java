public class Systeimport java.io.*;
import java.util.*;

public class Sys
{
	public static void main(String... args)
	{
		File dir = new File("/storage/sdcard0/sysDir");
		if(!dir.exists()) dir.mkdirs();
		FileWork fw = new FileWork();
		
		try
		{
			File fileCon = new File("/storage/sdcard0/sysDir/conf.txt");
			if(!fileCon.exists()) { 
			fileCon.createNewFile();
			
			Scanner sc = new Scanner(System.in);
			
			System.out.print("Имя: ");
			String getNameUser = sc.next();
			
			BufferedWriter bw = new BufferedWriter(new FileWriter(fileCon));
			bw.append(getNameUser);
			bw.close();
			
			fw.start(fileCon);
			
			} else {
			
			fw.start(fileCon);
			
			}
		}
		catch (IOException e)
		{}}
}