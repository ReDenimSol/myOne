import java.io.*;
import java.util.*;

public class FileWork
{
	public void start(File data) throws FileNotFoundException, IOException {
		if(data.canRead()) {
			
			ArrayList<String> dan = new ArrayList<>();
			
			BufferedReader br = new BufferedReader(new FileReader(data));
			String uName = br.readLine();
			
			dan.add("Shell Console User: " + uName);
			dan.add("Date: " + new Date());
			dan.add("Welcome!");
			dan.add("£ ");
			
			for(int i = 0; i < dan.size(); ++i)
			{
				System.out.println(dan.get(i));
				try
				{
					Thread.sleep(200);
				}
				catch (InterruptedException e)
				{}
			}
			
			Scanner sc = new Scanner(System.in);
			String cmnd = "";
			
			while(cmnd != "exit")
			{
				System.out.print(dan.get(dan.size() - 1));
				cmnd = sc.next();
				
				switch(cmnd)
				{
					case "ls":
						
						File centDir = new File("/storage/sdcard0/");
						File[] ls = centDir.listFiles();
						
						String[] files = new String[ls.length];
						long[] datesFiles = new long[files.length];
						Date[] dts = new Date[files.length];
						
						for(int i = 0; i < files.length; ++i)
						{
							files[i] = ls[i].getName();
							datesFiles[i] = ls[i].lastModified();
							dts[i] = new Date(datesFiles[i]);
						}
						
						for(int i = 0; i < ls.length; ++i)
						{
							System.out.println(files[i] + "\t" + dts[i].getHours() + ":" + dts[i].getMinutes());
						}
						break;
						case "touch":
							// Создание файла
							break;
							case "mkdir":
								// Создание папки
								break;
								case "wget":
									// Загрузка
									break;
									case "TCP":
										new InternetWork().TCP("127.0.0.1",  3929);
										break;
										case "HTTP":
											// Запрос
											break;
											case "exit":
												System.exit(0);
												break;
												case "UDP":
													// Запросить данные у пользователя
													break;
				}
			}
			
		}
	}
}